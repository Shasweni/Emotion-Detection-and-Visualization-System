import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'auth_service.dart'; // Import AuthService
import 'login.dart'; // Import LoginPage for navigation

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String? errorMessage;

  // Method to handle user registration
  void _handleRegister() async {
    String email = _emailController.text;
    String password = _passwordController.text;

    // Check for password length before registration
    if (password.length > 8) {
      setState(() {
        errorMessage = 'Password should not be more than 8 characters.';
      });
      return;
    }

    try {
      final user = await AuthService().createUserWithEmailAndPassword(email, password);
      if (user != null) {
        setState(() {
          errorMessage = null; // Clear error if registration is successful
        });
        // Show a success message in a SnackBar
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Registration successful! Please log in."),
            backgroundColor: Colors.green,
          ),
        );

        // Navigate to the login page
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      }
    } on FirebaseAuthException catch (e) {
      setState(() {
        // Handle specific Firebase errors
        if (e.code == 'email-already-in-use') {
          errorMessage = 'This email is already registered. Please use a different email.';
        } else if (e.code == 'weak-password') {
          errorMessage = 'Your password is too weak. Please use a stronger password.';
        } else if (e.code == 'invalid-email') {
          errorMessage = 'The email address is not valid. Please enter a valid email.';
        } else {
          errorMessage = 'Registration failed. Please try again.';
        }
      });
    } catch (e) {
      setState(() {
        errorMessage = 'An unknown error occurred: ${e.toString()}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.black, // Changed to black
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white, size: 30), // Larger, more visible back arrow
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Email Field with Larger Font
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8.0),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6.0)],
              ),
              child: TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'Email',
                  hintStyle: TextStyle(fontSize: 18.0), // Increased font size
                  labelText: 'Email',
                  labelStyle: TextStyle(fontSize: 18.0), // Increased font size
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)),
                  contentPadding: EdgeInsets.all(12.0),
                ),
              ),
            ),
            SizedBox(height: 16.0),

            // Password Field with Larger Font
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8.0),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6.0)],
              ),
              child: TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Password',
                  hintStyle: TextStyle(fontSize: 18.0), // Increased font size
                  labelText: 'Password',
                  labelStyle: TextStyle(fontSize: 18.0), // Increased font size
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)),
                  contentPadding: EdgeInsets.all(12.0),
                ),
              ),
            ),
            SizedBox(height: 4.0),

            // Note for password length with larger font
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Password should not be more than 8 characters.",
                style: TextStyle(color: Colors.redAccent, fontSize: 14.0), // Increased font size
              ),
            ),
            SizedBox(height: 24.0),

            // Error message display with larger font
            if (errorMessage != null)
              Text(
                errorMessage!,
                style: TextStyle(color: Colors.red, fontSize: 16.0), // Slightly larger font for error message
              ),

            // Register Button styled with shadow and larger font
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _handleRegister,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple, // Button color remains purple
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 14.0),
                  shadowColor: Colors.black,  // Black shadow for button
                  elevation: 10,  // Shadow elevation
                ),
                child: Text(
                  'REGISTER',
                  style: TextStyle(fontSize: 20.0, color: Colors.white), // Increased font size for REGISTER text
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
