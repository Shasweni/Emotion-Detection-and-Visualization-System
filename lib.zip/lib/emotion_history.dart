import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home.dart'; // Import your HomePageAfterLogin

class EmotionHistoryPage extends StatefulWidget {
  final int selectedIndex; // Accept selected index as a parameter

  EmotionHistoryPage({Key? key, required this.selectedIndex}) : super(key: key);

  @override
  _EmotionHistoryPageState createState() => _EmotionHistoryPageState();
}

class _EmotionHistoryPageState extends State<EmotionHistoryPage> {
  final User? user = FirebaseAuth.instance.currentUser;

  // Function to delete a specific emotion result from Firebase
  Future<void> _deleteEmotion(String emotionDocId) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user!.uid)
          .collection('emotions')
          .doc(emotionDocId)
          .delete();
      print("Emotion result deleted successfully.");
      // Refresh the UI explicitly after deletion
      setState(() {});
    } catch (e) {
      print("Failed to delete emotion: $e");
    }
  }

  // Show confirmation dialog before deleting
  Future<void> _showDeleteConfirmationDialog(String emotionDocId) async {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete this emotion result?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _deleteEmotion(emotionDocId); // Delete the emotion result
              },
              child: Text('Confirm'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        toolbarHeight: 80,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white, size: 28),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/Flower.png'),
            fit: BoxFit.cover,
            opacity: 0.12,
          ),
        ),
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('users')
              .doc(user?.uid) // Handle null user safely
              .collection('emotions')
              .orderBy('timestamp', descending: true)
              .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return const Center(child: Text('Error loading data'));
            }
            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(child: Text('No emotions found'));
            }

            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                final emotionData = snapshot.data!.docs[index];
                final timestamp = (emotionData['timestamp'] as Timestamp).toDate();
                final emotions = emotionData['emotions'];
                final userInput = emotionData['text'];
                final emotionDocId = emotionData.id; // Document ID for deletion

                return Card(
                  margin: EdgeInsets.all(10.0),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: Text(
                                'Date: ${timestamp.toLocal()}',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple,
                                ),
                                overflow: TextOverflow.ellipsis, // Prevent text overflow
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                _showDeleteConfirmationDialog(emotionDocId);
                              },
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Input: $userInput',
                          style: TextStyle(
                            fontSize: 18,
                            fontStyle: FontStyle.italic,
                            color: Colors.black54,
                          ),
                          overflow: TextOverflow.ellipsis, // Prevent text overflow
                        ),
                        SizedBox(height: 10),
                        DataTable(
                          columns: [
                            DataColumn(
                              label: Text(
                                'Emotion',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            DataColumn(
                              label: Text(
                                'Score (%)',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                          rows: emotions.map<DataRow>((emotion) {
                            final color = getColorForEmotion(emotion['label']); // Get color based on emotion
                            return DataRow(
                              cells: [
                                DataCell(Text(
                                  emotion['label'],
                                  style: TextStyle(color: color, fontSize: 17),
                                )),
                                DataCell(Text(
                                  '${(emotion['score'] * 100).toStringAsFixed(1)}%',
                                  style: TextStyle(color: color, fontSize: 17),
                                )),
                              ],
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: widget.selectedIndex,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.white,
        onTap: (index) {
          if (index == 0) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => HomePageAfterLogin()),
              (route) => false,
            );
          } else if (index == 1) {
            Navigator.pop(context);
          }
        },
      ),
    );
  }

  // Helper function to assign color based on emotion
  Color getColorForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'fear':
        return Colors.redAccent;
      case 'sadness':
        return Colors.blueAccent;
      case 'joy':
        return Colors.green;
      case 'anger':
        return Colors.orange;
      case 'surprise':
        return Colors.purple;
      case 'love':
        return Colors.pinkAccent;
      default:
        return Colors.black;
    }
  }
}
