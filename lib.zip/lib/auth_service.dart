import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Create a user with email and password
  Future<User?> createUserWithEmailAndPassword(String email, String password) async {
    try {
      final UserCredential cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return cred.user;  // Returns the created user
    } on FirebaseAuthException catch (e) {
      print("Error during registration: ${e.code} - ${e.message}");
      throw e;
    }
  }

  // Sign in a user with email and password
  Future<User?> signInWithEmailAndPassword(String email, String password) async {
    try {
      final UserCredential cred = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return cred.user;  // Returns the signed-in user
    } on FirebaseAuthException catch (e) {
      print("Error during sign-in: ${e.code} - ${e.message}");
      throw e;
    }
  }

  // Sign out the user
  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (e) {
      print("Error during sign-out: ${e.toString()}");
    }
  }

  // Send password reset email
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      print("Error sending reset email: ${e.code} - ${e.message}");
      throw e;
    }
  }

  // Check if a user is signed in
  User? getCurrentUser() {
    return _auth.currentUser;
  }
}
