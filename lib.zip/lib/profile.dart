import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'emotion_history.dart'; // Import the new EmotionHistoryPage
import 'home.dart'; // Import your HomePageAfterLogin, HomePageBeforeLogin
import 'auth_service.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final User? user = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        toolbarHeight: 80,
        automaticallyImplyLeading: false, // Remove back arrow
        title: null, // Remove title
      ),
      body: Stack(
        children: [
          // Background image with opacity
          Positioned.fill(
            child: Opacity(
              opacity: 0.12, // Adjusted transparency for consistency
              child: Image.asset(
                'assets/images/Flower.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
          user == null
              ? const Center(child: Text('User not logged in'))
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,  // Added to center the content
                  children: [
                    // User Details Section (Logged in as)
                    Padding(
                      padding: const EdgeInsets.only(top: 60.0, left: 16.0),
                      child: Text(
                        'Logged in as: ${user!.email}', // This is kept intact as per your request
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Container with Emotion Count and History Button - Centered in the screen
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Container(
                        padding: const EdgeInsets.all(20.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // Emotion Count Section with real-time updates
                            StreamBuilder<QuerySnapshot>(
                              stream: FirebaseFirestore.instance
                                  .collection('users')
                                  .doc(user!.uid)
                                  .collection('emotions')
                                  .snapshots(),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return const Center(child: CircularProgressIndicator());
                                }
                                if (snapshot.hasError) {
                                  return const Center(child: Text('Error loading emotion count'));
                                }
                                final emotionCount = snapshot.data?.docs.length ?? 0;
                                return Text(
                                  'Emotions Tested: $emotionCount',
                                  style: TextStyle(
                                    fontSize: 28, // Larger font size
                                    fontWeight: FontWeight.bold,
                                    color: Colors.purple,
                                  ),
                                );
                              },
                            ),
                            const SizedBox(height: 20), // Space between text and button
                            // View Emotion History Button
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () {
                                  // Navigate to EmotionHistoryPage with the selected index
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => EmotionHistoryPage(
                                              selectedIndex: 1,
                                            )), // Pass 1 for Profile
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.purple,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                  padding: EdgeInsets.symmetric(vertical: 16.0),
                                  shadowColor: Colors.purple[200],
                                  elevation: 10,
                                ),
                                child: const Text(
                                  'View Emotion History',
                                  style: TextStyle(fontSize: 20.0, color: Colors.white, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    // Logout Button smaller and positioned at bottom right
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * 0.3,
                          child: ElevatedButton(
                            onPressed: () {
                              AuthService().signOut();
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(builder: (context) => HomePageBeforeLogin()),
                                (route) => false,
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.redAccent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                              padding: EdgeInsets.symmetric(vertical: 10.0),
                              shadowColor: Colors.red[200],
                              elevation: 10,
                            ),
                            child: const Text(
                              'Logout',
                              style: TextStyle(fontSize: 16.0, color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: 1,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.white,
        onTap: (index) {
          if (index == 0) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => HomePageAfterLogin()),
              (route) => false,
            );
          } else if (index == 1) {
            // Do nothing as we are already on the ProfilePage
          }
        },
      ),
    );
  }
}
