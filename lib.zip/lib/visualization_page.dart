import 'package:flutter/material.dart';
import 'home.dart';
import 'profile.dart';
import 'dart:math';

class VisualizationPage extends StatelessWidget {
  final String emotion;
  final Map<String, double> emotionPercentages;

  VisualizationPage({required this.emotion, required this.emotionPercentages});

  // Define a map to associate each emotion with a color
  final Map<String, Color> emotionColors = {
    'joy': Colors.lightBlueAccent,
    'sadness': Colors.purple,
    'anger': Colors.redAccent,
    'fear': const Color.fromARGB(198, 214, 4, 123),
    'surprise': const Color.fromARGB(255, 97, 121, 17),
    'love': Colors.pinkAccent,
  };

  // Define a map to store quotes for each emotion
  final Map<String, List<String>> emotionQuotes = {
    'anger': [
      "Anger is like fire; it can warm your heart or burn it down. Choose to let it guide, not control.",
      "Anger shows us what we value and what we won’t accept—use it to build, not destroy.",
    ],
    'fear': [
      "Fear is a compass pointing to growth. Embrace it, and let courage light the way.",
      "Fear is not the absence of strength; it’s the birthplace of bravery.",
    ],
    'joy': [
      "Joy doesn’t come from what you have, but from seeing the beauty in what surrounds you.",
      "Joy is a choice made moment by moment—find it in the simplest things.",
    ],
    'love': [
      "Love is the thread that connects us all, reminding us we’re never truly alone.",
      "To love is to open yourself to both joy and vulnerability. Let it make you whole.",
    ],
    'sadness': [
      "Sadness is the soul’s way of asking for attention and care—listen, and let it heal you.",
      "Allow sadness to be a teacher; it reveals what you value and what you need to heal.",
    ],
    'surprise': [
      "Surprise is life’s reminder that we don’t know everything. Embrace the unexpected.",
      "Let surprise bring wonder into your life. It’s the doorway to curiosity and discovery.",
    ],
  };

  // Method to get a random quote based on the emotion
  String getRandomQuote(String emotion) {
    final quotes = emotionQuotes[emotion.toLowerCase()] ?? ["Quote not found"];
    return quotes[Random().nextInt(quotes.length)];
  }

  @override
  Widget build(BuildContext context) {
    // Get the screen dimensions for proportional scaling
    final double screenWidth = MediaQuery.of(context).size.width;

    // Get the color for the current emotion
    Color emotionColor = emotionColors[emotion.toLowerCase()] ?? Colors.purple;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        toolbarHeight: 80,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white, size: 30),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      bottomNavigationBar: SizedBox(
        height: 70,
        child: BottomNavigationBar(
          backgroundColor: Colors.black,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home, color: Colors.white),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person, color: Colors.white),
              label: 'Profile',
            ),
          ],
          selectedItemColor: Colors.purple,
          unselectedItemColor: Colors.white,
          onTap: (index) {
            if (index == 0) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => HomePageAfterLogin()),
                (route) => false,
              );
            } else if (index == 1) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfilePage()),
              );
            }
          },
        ),
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              'assets/images/Flower.png',
              fit: BoxFit.cover,
              alignment: Alignment.center,
              color: Colors.black.withOpacity(0.1),
              colorBlendMode: BlendMode.dstATop,
            ),
          ),
          // Center Content
          Center(
            child: Transform.scale(
              scale: 0.85, // Reduce the overall size of the page by 85%
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    top: 60,
                    child: _buildEmotionImages(emotion, 270),
                  ),
                  Positioned(
                    top: 4,
                    child: Image.asset(
                      'assets/images/$emotion/outline.png',
                      width: 330,
                      height: 380,
                      fit: BoxFit.contain,
                    ),
                  ),
                  Positioned(
                    top: 170,
                    child: Image.asset(
                      'assets/images/$emotion/stem.png',
                      width: 100,
                      height: 600,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 600,
                    child: Column(
                      children: [
                        Text(
                          emotion.toUpperCase(),
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                            color: emotionColor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 20), // Space between label and quote
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 40.0),
                          child: Container(
                            padding: EdgeInsets.all(16.0), // Add padding inside the container
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.8), // Light background color with opacity
                              borderRadius: BorderRadius.circular(12.0), // Rounded corners
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2), // Subtle shadow color
                                  blurRadius: 6.0, // Spread of shadow
                                  offset: Offset(0, 3), // Position of shadow
                                ),
                              ],
                            ),
                            child: ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: screenWidth * 0.8, // Ensure text wraps within 80% of screen width
                              ),
                              child: Text(
                                getRandomQuote(emotion),
                                style: TextStyle(
                                  fontFamily: 'Roboto', // Matching font with emotion label
                                  fontSize: 20, // Balanced font size for readability
                                  fontWeight: FontWeight.w500,
                                  color: emotionColor.withOpacity(0.9), // Consistent color
                                  height: 1.4, // Line height for comfortable reading
                                ),
                                textAlign: TextAlign.center,
                                softWrap: true, // Ensure text wraps to the next line
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmotionImages(String emotionFolder, double size) {
    List<Widget> imageWidgets = [];
    List<String> imageNames = ['anger', 'fear', 'joy', 'love', 'surprise', 'sadness'];

    for (int i = 0; i < imageNames.length; i++) {
      double angle = i * 45.0;
      double opacity = 0.3 + i * 0.1;
      imageWidgets.add(_buildEmotionImage(emotionFolder, imageNames[i], size, angle, opacity));
    }

    return Stack(
      alignment: Alignment.center,
      children: imageWidgets,
    );
  }

  Widget _buildEmotionImage(String emotionFolder, String emotionFile, double size, double angle, double opacity) {
    return Opacity(
      opacity: opacity,
      child: Transform.rotate(
        angle: angle * 3.1416 / 180,
        child: Image.asset(
          'assets/images/$emotionFolder/$emotionFile.png',
          width: size,
          height: size,
          errorBuilder: (context, error, stackTrace) =>
              Text('$emotionFile image not found'),
        ),
      ),
    );
  }
}
