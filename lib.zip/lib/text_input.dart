import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'home.dart';
import 'profile.dart';
import 'visualization_page.dart';

class TextInputPage extends StatefulWidget {
  const TextInputPage({super.key});

  @override
  _TextInputPageState createState() => _TextInputPageState();
}

class _TextInputPageState extends State<TextInputPage> {
  final TextEditingController _textController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Map<String, dynamic>> _emotionResult = [];

  Future<void> _storeEmotionData(String userInput, List emotions) async {
    final User? user = _auth.currentUser;
    if (user != null) {
      try {
        await _firestore
            .collection('users')
            .doc(user.uid)
            .collection('emotions')
            .add({
          'text': userInput,
          'emotions': emotions,
          'timestamp': Timestamp.now(),
        });
      } catch (e) {
        print('Failed to store emotion data: $e');
      }
    } else {
      print('Error: User not logged in');
    }
  }

  Future<void> _analyzeEmotion(String userInput) async {
    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:5000/analyze'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{'text': userInput}),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        List emotions = responseData['emotions'];

        await _storeEmotionData(userInput, emotions);

        setState(() {
          _emotionResult = emotions.map<Map<String, dynamic>>((emotion) {
            return {
              'label': emotion['label'],
              'score': (emotion['score'] * 100).toStringAsFixed(2),
            };
          }).toList();
        });
      } else {
        throw Exception('Failed to analyze emotion');
      }
    } catch (e) {
      setState(() {
        _emotionResult = [
          {'label': 'Error', 'score': '0'}
        ];
      });
      print('Error: $e');
    }
  }

  Map<String, dynamic> _getHighestEmotion() {
    return _emotionResult.reduce((curr, next) =>
        double.parse(curr['score']) > double.parse(next['score']) ? curr : next);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        toolbarHeight: 80,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white, size: 30),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          height: MediaQuery.of(context).size.height, // Ensures it takes full height
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/Flower.png'),
              fit: BoxFit.cover, // Ensures the background image fits the page
              alignment: Alignment.center,
              opacity: 0.15,
            ),
          ),
          child: Column(
            children: <Widget>[
              const SizedBox(height: 40),
              Text(
                'Share your thoughts or feelings:',
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.06,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 25),
              TextField(
                controller: _textController,
                maxLines: 5,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Type here...',
                  hintText: 'How are you feeling today?',
                  fillColor: Colors.white.withOpacity(0.8),
                  filled: true,
                ),
              ),
              const SizedBox(height: 25),
              ElevatedButton(
                onPressed: () {
                  String userInput = _textController.text;
                  _analyzeEmotion(userInput);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 18),
                ),
                child: const Text(
                  'Submit',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
              const SizedBox(height: 40),
              Text(
                'Emotion Result:',
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.05,
                  color: Colors.purple,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Column(
                children: _emotionResult.map((emotion) {
                  final color = getColorForEmotion(emotion['label']);
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${emotion['label']}:',
                          style: TextStyle(
                            color: color,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 10),
                        Text(
                          '${emotion['score']}%',
                          style: TextStyle(
                            color: color,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _emotionResult.isNotEmpty
                    ? () {
                        final highestEmotion = _getHighestEmotion();
                        final emotionPercentages = {
                          'anger': 92.17,
                          'fear': 7.64,
                          'joy': 0.08,
                          'love': 0.05,
                          'surprise': 0.03,
                          'sadness': 0.03,
                        };

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => VisualizationPage(
                              emotion: highestEmotion['label'],
                              emotionPercentages: emotionPercentages,
                            ),
                          ),
                        );
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 18),
                ),
                child: const Text(
                  'Visualize',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: 0,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.white,
        onTap: (index) {
          if (index == 0) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => HomePageAfterLogin()),
              (route) => false,
            );
          } else if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ProfilePage()),
            );
          }
        },
      ),
    );
  }

  Color getColorForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'fear':
        return Colors.redAccent;
      case 'sadness':
        return Colors.blueAccent;
      case 'joy':
        return Colors.green;
      case 'anger':
        return Colors.orange;
      case 'surprise':
        return Colors.purple;
      case 'love':
        return Colors.pinkAccent;
      default:
        return Colors.black;
    }
  }
}
