import 'package:flutter/material.dart';
// Import your AuthService
import 'login.dart'; // Import your LoginPage
import 'register.dart'; // Import Register Page
import 'text_input.dart'; // Import TextInputPage for emotion detection
import 'profile.dart'; // Import ProfilePage

// Home page before login (no footer, only register and login buttons)
class HomePageBeforeLogin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image that covers the full screen
          Positioned.fill(
            child: Opacity(
              opacity: 0.15, // Adjust transparency to make it subtle
              child: Image.asset(
                'assets/images/Flower.png', // Path to your image
                fit: BoxFit.cover,
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0), // Added padding to prevent overflow
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Centered icon and title text
                  Center(
                    child: Column(
                      children: [
                        Icon(Icons.emoji_emotions, color: Colors.purple, size: 32),
                        SizedBox(height: 8),
                        Text(
                          'Welcome to Emotion Detector!',
                          style: TextStyle(
                            fontSize: 32.0, // Main title font size
                            color: Colors.purple,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 12),
                  // Subtitle text, centered
                  Text(
                    'Discover your emotions every day',
                    style: TextStyle(
                      fontSize: 22.0, // Increased font size
                      color: Colors.black54,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Tap to start your journey!',
                    style: TextStyle(
                      fontSize: 20.0, // Larger subtitle font
                      color: Colors.purpleAccent,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 40.0),
                  // Register Button
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.8, // Adjust width to 80% of the screen
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => RegisterPage()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 16.0),
                        elevation: 10,
                        backgroundColor: Colors.purple,
                        shadowColor: Colors.purpleAccent,
                      ),
                      child: Text(
                        'Register',
                        style: TextStyle(fontSize: 24.0, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  // Login prompt, centered
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an account?",
                        style: TextStyle(color: Colors.black, fontSize: 18.0), // Increased font size
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => LoginPage()),
                          );
                        },
                        child: Text(
                          'Login here',
                          style: TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0, // Increased font size
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Home page after login (no back button on AppBar)
class HomePageAfterLogin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black, // Top bar color
        elevation: 0,
        toolbarHeight: 80, // Increased toolbar height to match Profile Page
        automaticallyImplyLeading: false, // Removed the back arrow
      ),
      body: Stack(
        children: [
          // Background image with opacity
          Positioned.fill(
            child: Opacity(
              opacity: 0.12, // Adjusted transparency for consistency
              child: Image.asset(
                'assets/images/Flower.png', // Path to your image
                fit: BoxFit.cover,
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Fun motivational header
                Text(
                  "Welcome Back!",
                  style: TextStyle(
                    fontSize: 28.0,
                    color: Colors.purple,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 10),
                Text(
                  "Let’s discover how you're feeling today.",
                  style: TextStyle(
                    fontSize: 19.0,
                    color: Colors.black54,
                    fontStyle: FontStyle.italic,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 40.0),
                // Test Your Emotion button with updated style
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.7,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => TextInputPage()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple, // Updated color to match theme
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      shadowColor: Colors.purple[200],
                      elevation: 15,
                    ),
                    child: Text(
                      'Test Your Emotion',
                      style: TextStyle(fontSize: 20.0, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black, // Bottom bar color
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.white, // Adjust to your preference
        onTap: (index) {
          if (index == 0) {
            // Do nothing for Home as we are already on this page
          } else if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ProfilePage()),
            );
          }
        },
      ),
    );
  }
}
