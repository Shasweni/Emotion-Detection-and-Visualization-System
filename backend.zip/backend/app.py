from flask import Flask, request, jsonify
from transformers import pipeline

app = Flask(__name__)

# Load the emotion classifier model with top_k=None to return all scores
emotion_classifier = pipeline(
    "text-classification", 
    model="bhadresh-savani/distilbert-base-uncased-emotion", 
    top_k=None
)

@app.route('/analyze', methods=['POST'])
def analyze_emotion():
    try:
        # Get the text input from the request
        data = request.get_json()
        text = data.get('text')

        # Get emotion predictions from the model
        results = emotion_classifier(text)[0]  # Extract the predictions

        # Create a list of emotions with their scores
        emotions = [{'label': res['label'], 'score': res['score']} for res in results]

        # Return the list of emotions as JSON
        return jsonify({'emotions': emotions})

    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
