import 'package:flutter/material.dart';
import 'auth_service.dart'; // Import AuthService
import 'home.dart'; // Import your Home page

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String? errorMessage;

  // Controllers for text input
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Login logic using Firebase authentication
  void _handleLogin() async {
    String email = _emailController.text;
    String password = _passwordController.text;

    try {
      final user = await AuthService().signInWithEmailAndPassword(email, password);
      if (user != null) {
        setState(() {
          errorMessage = null;
        });
        // Navigate to HomePageAfterLogin after successful login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePageAfterLogin()),
        );
      }
    } on Exception {
      setState(() {
        errorMessage = 'Invalid email or password, please try again.';
      });
    }
  }

  // Forgot Password function
  void _handleForgotPassword() async {
    String email = _emailController.text;

    if (email.isEmpty) {
      setState(() {
        errorMessage = 'Please enter your email address to reset your password.';
      });
      return;
    }

    try {
      await AuthService().sendPasswordResetEmail(email);
      setState(() {
        errorMessage = 'Password reset email sent! Check your inbox.';
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to send reset email. Please try again later.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.black, // Changed to black
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white, size: 30), // Larger, more visible back arrow
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Email Field with Larger Font
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8.0),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6.0)],
              ),
              child: TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'Email',
                  hintStyle: TextStyle(fontSize: 18.0), // Increased font size
                  labelText: 'Email',
                  labelStyle: TextStyle(fontSize: 18.0), // Increased font size
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)),
                  contentPadding: EdgeInsets.all(12.0),
                ),
              ),
            ),
            SizedBox(height: 16.0),

            // Password Field with Larger Font
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8.0),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6.0)],
              ),
              child: TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Password',
                  hintStyle: TextStyle(fontSize: 18.0), // Increased font size
                  labelText: 'Password',
                  labelStyle: TextStyle(fontSize: 18.0), // Increased font size
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)),
                  contentPadding: EdgeInsets.all(12.0),
                ),
              ),
            ),
            SizedBox(height: 16.0),

            // Error message display
            if (errorMessage != null)
              Text(
                errorMessage!,
                style: TextStyle(color: Colors.red, fontSize: 16.0), // Slightly larger font for error message
              ),
            SizedBox(height: 16.0),

            // Forgot Password Text Link with Larger Font
            GestureDetector(
              onTap: _handleForgotPassword,
              child: Text(
                'Forgot Password?',
                style: TextStyle(color: Colors.purple, fontSize: 16.0, decoration: TextDecoration.underline), // Increased font size, underline
              ),
            ),
            SizedBox(height: 16.0),

            // Login Button styled with shadow
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _handleLogin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple, // Button color remains purple
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 14.0),
                  shadowColor: Colors.black,  // Black shadow for button
                  elevation: 10,  // Shadow elevation
                ),
                child: Text(
                  'LOGIN',
                  style: TextStyle(fontSize: 20.0, color: Colors.white), // Increased font size for LOGIN text
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
