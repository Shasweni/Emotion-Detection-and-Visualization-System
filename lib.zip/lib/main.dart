import 'package:emotion_detection/home.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Add this for authentication
import 'firebase_options.dart';  // Import the configuration file

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase with the configuration for web support
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,  // Use the configuration file here
    );
  } catch (e) {
    print('Firebase initialization failed: $e');
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emotion Detection',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      // Use a stream to check user login status and redirect accordingly
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasData) {
            // If user is logged in, navigate to HomePageAfterLogin
            return HomePageAfterLogin(); // User is logged in
          } else {
            // If user is not logged in, show HomePageBeforeLogin
            return HomePageBeforeLogin(); // User is not logged in
          }
        },
      ),
    );
  }
} 
